<template>
    <div> 
      <div id="cat">
        <h2>Random Cat Fact:</h2>
        <p>{{ catFact?.fact }}</p>
      </div>
  
      <div id="weather">
        <h2>Current Weather:</h2>
        <p>Temp: {{ weather?.current_weather?.temperature }}°C</p>
        <p>Wind: {{ weather?.current_weather?.windspeed }} km/h</p>
      </div>
    </div>
  </template>
  
  <script setup>
import { catInformation } from '~/composer/catInformation';
import { weatherInformation } from '~/composer/weatherInformation';

  const catFact = await catInformation()
  const weather = await weatherInformation()
  </script>